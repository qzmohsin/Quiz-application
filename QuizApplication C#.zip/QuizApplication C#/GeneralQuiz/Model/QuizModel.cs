﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace GeneralQuiz
{
    class QuizModel
    {
        private string[,] questions = new string[20, 6];
        public QuizModel()
        {
            questions[0, 0] = "Who is called the father of Computers";
            questions[0, 1] = "Mark Anthony";
            questions[0, 2] = "*Charles Babbage";
            questions[0, 3] = "Lewis Martin";
            questions[0, 4] = "Nusian";
            

            //
            questions[1, 0] = "What is the capital of INDIA";
            questions[1, 1] = "Bengaluru";
            questions[1, 2] = "*Delhi";
            questions[1, 3] = "Mumbai";
            questions[1, 4] = "Haryana";
           

            questions[2, 0] = "which is the National bird of INDIA";
            questions[2, 1] = "*Peacock";
            questions[2, 2] = "Parrot";
            questions[2, 3] = "Ostrich";
            questions[2, 4] = "Hornbill";
           
            //
            questions[3, 0] = "Brass gets discoloured in air because of the presence of which of the following gases in air?";
            questions[3, 1] = "*Hydrogen sulphide";
            questions[3, 2] = "Oxygen";
            questions[3, 3] = "Nitrogen";
            questions[3, 4] = "Methane";
            

            //
            questions[4, 0] = "Which of the following is used in pencils?";
            questions[4, 1] = "Charcoal";
            questions[4, 2] = "Phosphorous";
            questions[4, 3] = "*Graphite";
            questions[4, 4] = "Lead";
           
            //
            questions[5, 0] = "Who is the owner of Marvel Studios";
            questions[5, 1] = "Warner Bros";
            questions[5, 2] = "*Walt Disney";
            questions[5, 3] = "21st Century Fox";
            questions[5, 4] = "Universal Studios";
            
            //
            questions[6, 0] = "Who invented the BALLPOINT PEN?";
            questions[6, 1] = "Warner Brothers";
            questions[6, 2] = "*Biro Brothers";
            questions[6, 3] = "Write Brothers";
            questions[6, 4] = "None of the above";
            
            //
            questions[7, 0] = "Sulphur is not present in";
            questions[7, 1] = "iron pyrites";
            questions[7, 2] = "gypsum";
            questions[7, 3] = "coal";
            questions[7, 4] = "*chlorapatite";
           
            //
            questions[8, 0] = "What Galileo invented?";
            questions[8, 1] = "Pendulum clock";
            questions[8, 2] = "Microscope";
            questions[8, 3] = "Barometer";
            questions[8, 4] = "*Thermometer";
           
            //
            questions[9, 0] = "Who is the Prime Minister of India";
            questions[9, 1] = "*Narendra Modi";
            questions[9, 2] = "Amit Shah";
            questions[9, 3] = "Rahul Gandhi";
            questions[9, 4] = "Rajnath Singh";

            //
            questions[10, 0] = "Which of them is not a vegetable";
            questions[10, 1] = "Cabbage";
            questions[10, 2] = "*Tomato";
            questions[10, 3] = "Spinach";
            questions[10, 4] = "Lettuce";

            questions[11, 0] = "Which of the following is a Mammal";
            questions[11, 1] = "Dog";
            questions[11, 2] = "*Blue Whale";
            questions[11, 3] = "Porcupine";
            questions[11, 4] = "Snake";

            questions[12, 0] = "Which of the following is the largest Island";
            questions[12, 1] = "*Greenland";
            questions[12, 2] = "Iceland";
            questions[12, 3] = "Fiji";
            questions[12, 4] = "Donute Islands";
           
        }
        public string getQuestion(int i)
        {
            return questions[i, 0];
        }
        public string getAnswer(int i,int j)
        {
            return questions[i, j];
        }


       
       
    }
}
