﻿using GeneralQuiz.Command;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
 

namespace GeneralQuiz.ViewModel
{
   public class StartButtonViewModel :INotifyPropertyChanged
    {
       public ICommand sstartbuttonCommand {get; set;}
       public ICommand answer1ButtonCommand { get; set; }
       public ICommand answer2ButtonCommand { get; set; }
       public ICommand answer3ButtonCommand { get; set; }
       public ICommand answer4ButtonCommand { get; set; }
       public ICommand restartButtonCommand { get; set; }
       public ICommand SkipButtonCommand { get; set; }
       public ICommand SubmitButtonCommand { get; set; }
       public ICommand NextButtonCommand { get; set; }
       


       private QuizModel q = new QuizModel();
       private List<int> lst = new List<int>();
       private string ans;
       public static int score = 0;
       private int number = 1;
       public int previousQuestion = 0;
       public static int counter = 0;

       public StartButtonViewModel()
       {
         
           ForegroundOptionsColor = "#FFFFFFFF";
           ForegroundOptionsColor2 = "#FFFFFFFF";
           ForegroundOptionsColor3 = "#FFFFFFFF";
           ForegroundOptionsColor4 = "#FFFFFFFF";

          // if (sstartbuttonCommand==  null)
           sstartbuttonCommand = new StartButtonCommand(Execute, CanExecuteStart, false);

           //if (answer1ButtonCommand != null)
             answer1ButtonCommand = new StartButtonCommand(answer1Method, CanExecute, false);

          // if (answer2ButtonCommand != null)
             answer2ButtonCommand = new StartButtonCommand(answer2Method, CanExecute, false);

           //if (answer3ButtonCommand != null)
             answer3ButtonCommand = new StartButtonCommand(answer3Method, CanExecute, false);

           //if (answer4ButtonCommand != null)
             answer4ButtonCommand = new StartButtonCommand(answer4Method, CanExecute, false);

          // if (restartButtonCommand != null)
             restartButtonCommand = new StartButtonCommand(restartButtonMethod, CanExecute, false);


             NextButtonCommand = new StartButtonCommand(NextButtonMethod, CanExecuteNext, false);

             SkipButtonCommand = new StartButtonCommand(SkipButtonMethod, CanExecuteSkip, false);

             SubmitButtonCommand = new StartButtonCommand(SubmitButtonMethod, CanExecute, false);
       }

     
      public bool CanExecuteNext(object parameter)
       {
           if (number.Equals(11))
               return false;
           else
               return true;
       }

      public bool CanExecuteSkip(object parameter)
      {
          if (number.Equals(2))
              return false;
          else
              return true;
      }

      //public bool CanExecuteSumit\\(object parameter)
      //{
      //    return false;
      //}


       


       public bool CanExecute(object paramter)
       {
           return true;

              
       }

       private void dtClockTime_Tick(object sender, EventArgs e)
       {
           LblTimer = DateTime.Now.ToLongTimeString();

          
       }

       public void Execute(object paramter)
       
{
    counter++;
          

            DispatcherTimer dt = new DispatcherTimer();
           
           dt.Interval = new TimeSpan(0, 0, 1); //in Hour, Minutes, Second.
           dt.Tick += dtClockTime_Tick;
           dt.Start();

           PreviousButtonVisibility = true;
           SubmitButtonVisibility = true;
           NextQuestionVisibility = true;
           StartButtonVisibility = false;
           QuestVisibility = true;
           Answer1ButtonVisibility = true;
           Answer2ButtonVisibility = true;
           Answer3ButtonVisibility = true;
           Answer4ButtonVisibility = true;
           ScoreLabelVisibility = true;
           UserNameLabelVisibility = false;
           UserNameTextBoxVisibility = false;
           LblGetStarted = true;

           this.number++;

          
           int i = this.getRandom();
        

           QuestContent = q.getQuestion(i);
           Answer1Content= q.getAnswer(i, 1);
           Answer2Content = q.getAnswer(i, 2);
           Answer3Content = q.getAnswer(i, 3);
           Answer4Content = q.getAnswer(i, 4);
           QuestionNumberLbl =  "Question Number" + "  " + counter.ToString();

           if (Convert.ToString(Answer1Content).StartsWith("*"))
           {
               this.ans = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
               Answer1Content = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
           }
           else
           {
               if (Convert.ToString(Answer2Content).StartsWith("*"))
               {
                   this.ans = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
                   Answer2Content = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
               }
               else
               {
                   if (Convert.ToString(Answer3Content).StartsWith("*"))
                   {
                       this.ans = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                       Answer3Content = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                   }
                   else
                   {
                       this.ans = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                       Answer4Content = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                   }
               }
           }


           lst.Add(i);
       }

       public override string ToString()
       {
           return counter.ToString();
       }

       public void SkipButtonMethod(object paramter)
       {
           int i = this.getRandom();
           ForegroundOptionsColor = "#FFFFFFFF";
           ForegroundOptionsColor2 = "#FFFFFFFF";
           ForegroundOptionsColor3 = "#FFFFFFFF";
           ForegroundOptionsColor4 = "#FFFFFFFF";
           counter = counter - 1;
           previousQuestion = i;
           QuestContent = q.getQuestion(previousQuestion);
           Answer1Content = q.getAnswer(previousQuestion, 1);
           Answer2Content = q.getAnswer(previousQuestion, 2);
           Answer3Content = q.getAnswer(previousQuestion, 3);
           Answer4Content = q.getAnswer(previousQuestion, 4);
           
           QuestionNumberLbl = "Question Number" + "  " + counter.ToString();

           if (Convert.ToString(Answer1Content).StartsWith("*"))
           {
               this.ans = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
               Answer1Content = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
           }
           else
           {
               if (Convert.ToString(Answer2Content).StartsWith("*"))
               {
                   this.ans = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
                   Answer2Content = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
               }
               else
               {
                   if (Convert.ToString(Answer3Content).StartsWith("*"))
                   {
                       this.ans = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                       Answer3Content = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                   }
                   else
                   {
                       this.ans = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                       Answer4Content = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                   }
               }
           }
          
       }


       public void NextButtonMethod(object parameter)
       {
           
           

           if (this.number <= 10)
           {

               this.number++;
               int i = this.getRandom();
               previousQuestion = i;


               ForegroundOptionsColor = "#FFFFFFFF";
               ForegroundOptionsColor2 = "#FFFFFFFF";
               ForegroundOptionsColor3 = "#FFFFFFFF";
               ForegroundOptionsColor4 = "#FFFFFFFF";

               QuestContent = q.getQuestion(i);
               Answer1Content = q.getAnswer(i, 1);
               Answer2Content = q.getAnswer(i, 2);
               Answer3Content = q.getAnswer(i, 3);
               Answer4Content = q.getAnswer(i, 4);
               counter++;
               QuestionNumberLbl = "Question Number" + "  " + counter.ToString();

               if (Convert.ToString(Answer1Content).StartsWith("*"))
               {
                   this.ans = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
                   Answer1Content = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
               }
               else
               {
                   if (Convert.ToString(Answer2Content).StartsWith("*"))
                   {
                       this.ans = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
                       Answer2Content = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
                   }
                   else
                   {
                       if (Convert.ToString(Answer3Content).StartsWith("*"))
                       {
                           this.ans = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                           Answer3Content = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                       }
                       else
                       {
                           this.ans = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                           Answer4Content = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                       }
                   }
               }
               lst.Add(i);

           }
       }


       public void SubmitButtonMethod(object paramter)
       {
           
               MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show("Do you want to attempt the skipped questions before submitting", "Submitting the answers", System.Windows.MessageBoxButton.YesNo);
                    if (messageBoxResult == MessageBoxResult.Yes)
                    {
                        RestartVisibility = true;
                        QuestVisibility = false;
                        Answer1ButtonVisibility = false;
                        Answer2ButtonVisibility = false;
                        Answer3ButtonVisibility = false;
                        Answer4ButtonVisibility = false;
                        finalVisibility = true;
                        PreviousButtonVisibility = false;
                        NextQuestionVisibility = false;
                        QuestionNumberVisibility = false;
                        SubmitButtonVisibility = false;

                        DateTimeEnd = DateTime.Now.ToLongDateString();
                        

                            if(score > 5)
                            {
                                FinalContent = "         You have passed the test" + "\n          Your score is " + score;

                                PassFail = "Congratulations!!";
                            }

                            else
                            {
                                FinalContent = "         You haven't qualified " + "\n          Your score is " + score;

                                PassFail = "Better luck Next time!!";
                            }

                        

                        

                        //  restart.Visibility = Visibility.Visible;
                    }
                    else
                    {
                        for (int i = 1; i < 10; i++)
                        {
                            if(!lst.Contains(i))
                            {
                                int j = this.getRandom();
                                QuestContent = q.getQuestion(j);
                                Answer1Content = q.getAnswer(j, 1);
                                Answer2Content = q.getAnswer(j, 2);
                                Answer3Content = q.getAnswer(j, 3);
                                Answer4Content = q.getAnswer(j, 4);
                            }
                        }
                    }
               
                       
       }

         
           





















       public void answer1Method(object parameter)
       {

           ForegroundOptionsColor = "#FFFFFF00";
           ForegroundOptionsColor2 = "#FFFFFFFF";
           ForegroundOptionsColor3 = "#FFFFFFFF";
           ForegroundOptionsColor4 = "#FFFFFFFF";

           if (Convert.ToString(Answer2Content) == this.ans)
               score++;


              ScoreContent = "Score : " + score;
           //}
           
           
               
               //restart.Visibility = Visibility.Visible;
           
       }


       public void answer2Method(object parameter)
       {

           
           ForegroundOptionsColor = "#FFFFFFFF";
           ForegroundOptionsColor2 = "#FFFFFF00";
           ForegroundOptionsColor3 = "#FFFFFFFF";
           ForegroundOptionsColor4 = "#FFFFFFFF";
           //if (this.number < 11)
           //{
           //    this.number++;
               if (Convert.ToString(Answer2Content) == this.ans)
                   score++;
       
              ScoreContent = "Score : " + score;
         //  }
           
           
              
             //  restart.Visibility = Visibility.Visible;
           
       }

       public void answer3Method(object parameter)
       {

           ForegroundOptionsColor = "#FFFFFFFF";
           ForegroundOptionsColor2 = "#FFFFFFFF";
           ForegroundOptionsColor3 = "#FFFFFF00";
           ForegroundOptionsColor4 = "#FFFFFFFF";
           //if (this.number < 11)
           //{
           //    this.number++;
               if (Convert.ToString(Answer3Content) == this.ans)
                   score++;
               
             ScoreContent= "Score : " + score;
          // }
           
           
           
       }

           public void answer4Method(object parameter)
       {

           ForegroundOptionsColor = "#FFFFFFFF";
           ForegroundOptionsColor2 = "#FFFFFFFF";
           ForegroundOptionsColor3 = "#FFFFFFFF";
           ForegroundOptionsColor4 = "#FFFFFF00"; 
           //if (this.number < 11)
           //{
           //    this.number++;
               if (Convert.ToString(Answer4Content) == this.ans)
                   score++;
              
             ScoreContent = "Score : " + score;
          // }
           
           
              
          
           

         }




       public void restartButtonMethod(object parameter)
           {
               counter = 1;
            score = 0;
          ScoreContent = "Score : " + score;
            this.number = 1;
          //  final.Visibility = Visibility.Hidden;
            lst.Clear();
           // restart.Visibility = Visibility.Hidden;
            QuestVisibility = true;
            Answer1ButtonVisibility = true;
            Answer2ButtonVisibility = true;
            Answer3ButtonVisibility = true;
            Answer4ButtonVisibility = true;
            RestartVisibility = false;
            SubmitButtonVisibility = true;
            PreviousButtonVisibility = true;
            NextQuestionVisibility = true;
            QuestionNumberVisibility = true; ;
            FinalVisibility = false;
            FinalContent = "";
           // QuestionNumberLbl = "";


            QuestionNumberLbl = "Question Number" + " " + counter.ToString();
            
           // scoreLbl.Visibility = Visibility.Visible;
            
            int i = this.getRandom();
           QuestContent = q.getQuestion(i);
            
            Answer1Content = q.getAnswer(i, 1);
            Answer2Content = q.getAnswer(i, 2);
            Answer3Content = q.getAnswer(i, 3);
            Answer4Content = q.getAnswer(i, 4);
            if (Convert.ToString(Answer1Content).StartsWith("*"))
            {
                this.ans = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
                Answer1Content = Convert.ToString(Answer1Content).Substring(1, Convert.ToString(Answer1Content).Length - 1);
            }
            else
            {
                if (Convert.ToString(Answer2Content).StartsWith("*"))
                {
                    this.ans = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
                    Answer2Content = Convert.ToString(Answer2Content).Substring(1, Convert.ToString(Answer2Content).Length - 1);
                }
                else
                {
                    if (Convert.ToString(Answer3Content).StartsWith("*"))
                    {
                        this.ans = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                        Answer3Content = Convert.ToString(Answer3Content).Substring(1, Convert.ToString(Answer3Content).Length - 1);
                    }
                    else
                    {
                        this.ans = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                        Answer4Content = Convert.ToString(Answer4Content).Substring(1, Convert.ToString(Answer4Content).Length - 1);
                    }
                }
            }
            lst.Add(i);
        
    }
           

       public int getRandom()
       {
           Random rnd = new Random();
           int i = rnd.Next(11);
           if (lst.Contains(i) && lst.Count() < 11)
               while (lst.Contains(i))
                   i = rnd.Next(0, 11);
           return i;
       }






       public event PropertyChangedEventHandler PropertyChanged;

       private void RaisePropertyChanged(String info)
       {
           if (PropertyChanged != null)
               PropertyChanged(this, new PropertyChangedEventArgs(info));
       }






       public bool CanExecuteStart(object paramter)
       {
           //if (string.IsNullOrEmpty(UserNameLabelText))
           //    return false;

           //else
           return true;

       }


       /// <summary>
       /// Start Button visibility
       /// </summary>
       private bool _startbuttonvisibility = true;

       public bool StartButtonVisibility
       {
           get { return _startbuttonvisibility; }
           set
           {
               _startbuttonvisibility = value;
               RaisePropertyChanged("StartButtonVisibility");
           }
       }



       /// <summary>
       /// Answer1Buton Property
       /// </summary>
       private bool _answer1buttonvisibility = false;

       public bool Answer1ButtonVisibility
       {
           get { return _answer1buttonvisibility; }
           set
           {
               _answer1buttonvisibility = value;
               RaisePropertyChanged("Answer1ButtonVisibility");

           }
       }

       /// <summary>
       /// Answer2Buton Property
       /// </summary>
       private bool _answer2buttonvisibility = false;

       public bool Answer2ButtonVisibility
       {
           get { return _answer2buttonvisibility; }
           set
           {
               _answer2buttonvisibility = value;
               RaisePropertyChanged("Answer2ButtonVisibility");

           }
       }

       /// <summary>
       /// Answer3Button Property
       /// </summary>
       private bool _answer3buttonvisibility = false;

       public bool Answer3ButtonVisibility
       {
           get { return _answer3buttonvisibility; }
           set
           {
               _answer3buttonvisibility = value;
               RaisePropertyChanged("Answer3ButtonVisibility");

           }
       }


       /// <summary>
       /// Answer4Button Property
       /// </summary>
       private bool _answer4buttonvisibility = false;

       public bool Answer4ButtonVisibility
       {
           get { return _answer4buttonvisibility; }
           set
           {
               _answer4buttonvisibility = value;
               RaisePropertyChanged("Answer4ButtonVisibility");

           }
       }


       /// <summary>
       /// scorelbl Property
       /// </summary>
       private bool _scorelabelvisibility = false;

       public bool ScoreLabelVisibility
       {
           get { return _scorelabelvisibility; }
           set
           {
               _scorelabelvisibility = value;
               RaisePropertyChanged("ScoreLabelVisibility");

           }
       }

       /// <summary>
       /// question Line visibility Property
       /// </summary>
       private bool _questvisibility = false;

       public bool QuestVisibility
       {
           get { return _questvisibility; }
           set
           {
               _questvisibility = value;
               RaisePropertyChanged("QuestVisibility");

           }
       }


       /// <summary>
       /// NextQuestion Visibility
       /// </summary>
       private bool _nextquestionvisibility = false;

       public bool NextQuestionVisibility
       {
           get { return _nextquestionvisibility; }
           set
           {
               _nextquestionvisibility = value;
               RaisePropertyChanged("NextQuestionVisibility");

           }
       }

       /// <summary>
       /// final label Visibility
       /// </summary>
       private bool finalVisibility = true;
       public bool FinalVisibility
       {
           get { return finalVisibility; }
           set
           {
               finalVisibility = value;
               RaisePropertyChanged("FinalVisibility");

           }
       }

       /// <summary>
       /// UserName text box visivbility
       /// </summary>
       private bool _usernamelabelvisibility = true;

       public bool UserNameLabelVisibility
       {
           get { return _usernamelabelvisibility; }
           set
           {
               _usernamelabelvisibility = value;
               RaisePropertyChanged("UserNameLabelVisibility");

           }
       }



       /// <summary>
       ///UserNAme Label Content
       /// </summary>
       private string _usernamelabeltext;

       public string UserNameLabelText
       {
           get { return _usernamelabeltext; }
           set
           {
               _usernamelabeltext = value;

               RaisePropertyChanged("UserNameLabelText");


           }
       }

       private string _questionnumberlbl;

       public string QuestionNumberLbl
       {
           get { return _questionnumberlbl; }
           set
           {
               _questionnumberlbl = value;
               RaisePropertyChanged("QuestionNumberLbl");

           }
       }


       /// <summary>
       /// questionLine Content Property
       /// </summary>
       private string _questcontent;

       public string QuestContent
       {
           get { return _questcontent; }
           set
           {
               _questcontent = value;
               RaisePropertyChanged("QuestContent");

           }
       }

       /// <summary>
       /// Answer1Content Property
       /// </summary>
       private string _answer1content;

       public string Answer1Content
       {
           get { return _answer1content; }
           set
           {
               _answer1content = value;
               RaisePropertyChanged("Answer1Content");

           }
       }

       /// <summary>
       /// Answer2Content Property
       /// </summary>
       private string _answer2content;

       public string Answer2Content
       {
           get { return _answer2content; }
           set
           {
               _answer2content = value;
               RaisePropertyChanged("Answer2Content");

           }
       }

       /// <summary>
       /// Answer3Content Property
       /// </summary>
       private string _answer3content;

       public string Answer3Content
       {
           get { return _answer3content; }
           set
           {
               _answer3content = value;
               RaisePropertyChanged("Answer3Content");

           }
       }


       /// <summary>
       /// Answer4Content Property
       /// </summary>
       private string _answer4content;

       public string Answer4Content
       {
           get { return _answer4content; }
           set
           {
               _answer4content = value;
               RaisePropertyChanged("Answer4Content");

           }
       }

       private string finalContent;

       public string FinalContent
       {
           get { return finalContent; }
           set
           {
               finalContent = value;
               RaisePropertyChanged("FinalContent");

           }
       }

       private string scoreContent;

       public string ScoreContent
       {
           get { return scoreContent; }
           set
           {
               scoreContent = value;
               RaisePropertyChanged("ScoreContent");

           }
       }


       private string _lblTimer;

       public string LblTimer
       {
           get { return _lblTimer; }
           set
           {
               _lblTimer = value;
               RaisePropertyChanged("LblTimer");

           }
       }


       private bool _lblGetStarted = false;

       public bool LblGetStarted
       {
           get { return _lblGetStarted; }
           set
           {
               _lblGetStarted = value;
               RaisePropertyChanged("LblGetStarted");

           }
       }


       private bool _submitButtonVisibility = false;

       public bool SubmitButtonVisibility
       {
           get { return _submitButtonVisibility; }
           set
           {
               _submitButtonVisibility = value;
               RaisePropertyChanged("SubmitButtonVisibility");

           }
       }



       private string _passFail;

       public string PassFail
       {
           get { return _passFail; }
           set
           {
               _passFail = value;
               RaisePropertyChanged("PassFail");

           }
       }





       private bool _userNameTextBoxVisibility = true;

          public bool UserNameTextBoxVisibility
       {
           get { return _userNameTextBoxVisibility; }
           set
           {
               _userNameTextBoxVisibility = value;
               RaisePropertyChanged("UserNameTextBoxVisibility");

           }
       }


          private bool _previousButtonVisibility = false;

          public bool PreviousButtonVisibility
          {
              get { return _previousButtonVisibility; }
              set
              {
                  _previousButtonVisibility = value;
                  RaisePropertyChanged("PreviousButtonVisibility");

              }
          }



          private bool _questionNumberVisibility = true;

          public bool QuestionNumberVisibility
          {
              get { return _questionNumberVisibility; }
              set
              {
                  _questionNumberVisibility = value;
                  RaisePropertyChanged("QuestionNumberVisibility");

              }
          }


          private bool _restartVisibility = false;

          public bool RestartVisibility
          {
              get { return _restartVisibility; }
              set
              {
                  _restartVisibility = value;
                  RaisePropertyChanged("RestartVisibility");

              }
          }


          private string _foregroundOptionsColor;

          public string ForegroundOptionsColor
          {
              get { return _foregroundOptionsColor; }
              set
              {
                  _foregroundOptionsColor = value;
                  RaisePropertyChanged("ForegroundOptionsColor");

              }
          }


        private string _foregroundOptionsColor2;

          public string ForegroundOptionsColor2
          {
              get { return _foregroundOptionsColor2; }
              set
              {
                  _foregroundOptionsColor2 = value;
                  RaisePropertyChanged("ForegroundOptionsColor2");

              }
          }

          private string _foregroundOptionsColor3;

          public string ForegroundOptionsColor3
          {
              get { return _foregroundOptionsColor3; }
              set
              {
                  _foregroundOptionsColor3 = value;
                  RaisePropertyChanged("ForegroundOptionsColor3");

              }
          }


          private string _foregroundOptionsColor4;

          public string ForegroundOptionsColor4
          {
              get { return _foregroundOptionsColor4; }
              set
              {
                  _foregroundOptionsColor4 = value;
                  RaisePropertyChanged("ForegroundOptionsColor4");

              }
          }













       
         

          private string _dateTimeEnd;

          public string  DateTimeEnd
          {
              get { return _dateTimeEnd; }
              set
              {
                  _dateTimeEnd = value;
                  RaisePropertyChanged("DateTimeEnd");

              }
          }
    }
}
