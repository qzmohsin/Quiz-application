﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
 

namespace GeneralQuiz.Command
{
  public  class StartButtonCommand:ICommand
    {
      Action<object> executeCommand;
      Func<object,bool> canexecuteCommand;
      bool canexecutecache;
      public StartButtonCommand(Action<object> executeCommand, Func<object,bool> canexecuteCommand, bool canexecutecache)
      {
          this.executeCommand = executeCommand;
          this.canexecuteCommand = canexecuteCommand;
          this.canexecutecache = canexecutecache;

      }
      
        public bool CanExecute(object parameter)
        {
            if (canexecuteCommand == null)
            {
                 return true;
            }
            else{
                return canexecuteCommand(parameter);
            }
               
            
        }

        public event EventHandler CanExecuteChanged
   {
       add
       {
           CommandManager.RequerySuggested += value;
           

       }

           remove
       {
           CommandManager.RequerySuggested -= value;
       }

            
   }

        public void Execute(object parameter)
        {
            executeCommand(parameter);
        }
    }
}
